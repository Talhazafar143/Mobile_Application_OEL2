package com.example.samdoel2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class Login extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                String password = etPassword.getText().toString().trim();



                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(Login.this, "Please enter email and password", Toast.LENGTH_SHORT).show();
                } else {
                    boolean loggedIn = loginUser(email, password);
                    if (loggedIn) {

                        Toast.makeText(Login.this, "Login successful!", Toast.LENGTH_SHORT).show();
                        retrieveUserData(email);
                    } else {
                        Toast.makeText(Login.this, "Invalid email or password", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
    private boolean loginUser(String email, String password) {
        String fileName = email + ".txt";

        try {
            FileInputStream fileInputStream = openFileInput(fileName);
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String line;
            StringBuilder userData = new StringBuilder();

            while ((line = bufferedReader.readLine()) != null) {
                userData.append(line);
                userData.append("\n");
            }

            bufferedReader.close();
            inputStreamReader.close();
            fileInputStream.close();
            String savedPassword = extractPassword(userData.toString());
            return savedPassword.equals(password);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
    private String extractPassword(String userData) {
        String[] lines = userData.split("\n");
        for (String line : lines) {
            if (line.startsWith("Password:")) {
                return line.substring(line.indexOf(":") + 1).trim();
            }
        }
        return "";
    }
    private void retrieveUserData(String email) {
        String name = ""; // Initialize the user's name variable
        String role = ""; // Initialize the user's role variable

        try {
            FileInputStream fileInputStream = openFileInput(email + ".txt");
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

            // Read the user data line by line
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                // Split the line into key-value pairs
                String[] keyValue = line.split(":");
                if (keyValue.length == 2) {
                    String key = keyValue[0].trim();
                    String value = keyValue[1].trim();

                    if (key.equals("Name")) {
                        name = value;
                    } else if (key.equals("Role")) {
                        Log.d("abcd",role);
                        role = value;
                    }
                }
            }

            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error retrieving user data", Toast.LENGTH_SHORT).show();
        }

        // Start the appropriate activity based on the user's role
        if (role.equals("Citizen")) {
            Intent intent = new Intent(Login.this, ProfileActivity.class);
            intent.putExtra("name", name); // Pass the user's name
            intent.putExtra("email", email); // Pass the user's email
            intent.putExtra("role", role); // Pass the user's role ("Citizen")
            startActivity(intent);
        } else {
            Intent intent = new Intent(Login.this, EmergencyActivity.class);
            intent.putExtra("name", name); // Pass the user's name
            intent.putExtra("email", email); // Pass the user's email
            intent.putExtra("role", role); // Pass the user's role ("Emergency Responder")
            startActivity(intent);
        }
    }


}
