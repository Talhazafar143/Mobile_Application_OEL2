package com.example.samdoel2;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPassword, etContactNumber;
    private Spinner spinnerRole;
    private Button btnSignup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etContactNumber = findViewById(R.id.etContactNumber);
        spinnerRole = findViewById(R.id.spinnerRole);
        btnSignup = findViewById(R.id.btnSignup);

        Button btnGoToLogin = findViewById(R.id.btnGoToLogin);
        btnGoToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Login.class);
                startActivity(intent);
            }
        });

        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString().trim();
                String email = etEmail.getText().toString().trim();
                String password = etPassword.getText().toString().trim();
                String contactNumber = etContactNumber.getText().toString().trim();
                String role = spinnerRole.getSelectedItem().toString();

                if (name.isEmpty() || email.isEmpty() || password.isEmpty() || contactNumber.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else if (!isValidEmail(email)) {
                    Toast.makeText(MainActivity.this, "Invalid email address", Toast.LENGTH_SHORT).show();
                } else {
                    if (isExistingUser(email)) {
                        Toast.makeText(MainActivity.this, "User with this email already exists", Toast.LENGTH_SHORT).show();
                    } else {
                        saveUserData(name, email, password, contactNumber, role);
                        Toast.makeText(MainActivity.this, "Signup successful!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, Login.class);
                        startActivity(intent);
                    }
                }
            }
        });
    }
    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}$";
        return email.matches(emailRegex);
    }
    private boolean isExistingUser(String email) {
        String fileName = email + ".txt";
        String[] fileList = fileList();
        for (String file : fileList) {
            if (file.equals(fileName)) {
                return true;
            }
        }
        return false;
    }

    private void saveUserData(String name, String email, String password, String contactNumber, String role) {
        String userData = "Name: " + name + "\n" +
                "Email: " + email + "\n" +
                "Password: " + password + "\n" +
                "Contact Number: " + contactNumber + "\n" +
                "Role: " + role;

        try {
            FileOutputStream fileOutputStream = openFileOutput(email + ".txt", MODE_PRIVATE);
            fileOutputStream.write(userData.getBytes());
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error saving user data", Toast.LENGTH_SHORT).show();
        }
    }
}