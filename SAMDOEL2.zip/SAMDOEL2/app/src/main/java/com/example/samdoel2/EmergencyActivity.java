package com.example.samdoel2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class EmergencyActivity extends AppCompatActivity {
    private TextView UserInfo;
    private LinearLayout llSavedTexts;
    private String userName;
    private String userEmail;
    private String userRole;
    private Button respondBtn;
    private EditText editText;
    private String pendingRespondsFolderName = "PendingResponds";
    private String settledRespondsFolderName = "SettledResponds";
    private String respUser;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            userName = extras.getString("name");
            userEmail = extras.getString("email");
            userRole = extras.getString("role");
        }

        UserInfo = findViewById(R.id.tvUserInfo);
        llSavedTexts = findViewById(R.id.llSavedTexts);
        respondBtn = findViewById(R.id.btnRespond);

        editText=findViewById((R.id.etEmail));


        String userInfo = "Name: " + userName + "\n" +
                "Email: " + userEmail + "\n" +
                "Role: " + userRole;
        UserInfo.setText(userInfo);

        respondBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                respUser=editText.getText().toString();
                showDialogBox();
            }
        });

        Button btnLogout = findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EmergencyActivity.this, Login.class);
                startActivity(intent);
                finish();
            }
        });

        loadSavedTexts();
    }

    private void showDialogBox() {
        AlertDialog.Builder builder = new AlertDialog.Builder(EmergencyActivity.this);
        builder.setTitle("Respond to User");
        builder.setMessage("Enter your response:");
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_respond, null);
        final EditText etResponse = dialogView.findViewById(R.id.etResponse);
        builder.setView(dialogView);
        builder.setPositiveButton("Respond", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String response = etResponse.getText().toString().trim();
                if (!response.isEmpty()) {
                    saveResponse(response,respUser);
                    deletePendingResponse(respUser);
                    Toast.makeText(EmergencyActivity.this, "Response sent and pending notification deleted", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }
    private void saveResponse(String response, String repUser) {
        File settledFolder = getOrCreateFolder(settledRespondsFolderName);

        String fileName = repUser + "_" + "response" + ".txt";
        File responseFile = new File(settledFolder, fileName);
        Log.d("respUser", repUser);

        try {
            if (!responseFile.exists()) {
                if (responseFile.createNewFile()) {
                    Log.i("SaveResponse", "Response file created successfully");
                    Log.i("SaveResponse", "File path: " + responseFile.getAbsolutePath());
                } else {
                    Log.e("SaveResponse", "Failed to create response file");
                }
            }

            FileWriter writer = new FileWriter(responseFile);
            writer.write(response);
            writer.close();

// Read the file content
            StringBuilder fileContent = new StringBuilder();
            try {
                Scanner scanner = new Scanner(responseFile);
                while (scanner.hasNextLine()) {
                    fileContent.append(scanner.nextLine());
                }
                scanner.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Log.i("SaveResponse", "File content: " + fileContent.toString());

            Log.i("SaveResponse", "Response saved successfully");
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(EmergencyActivity.this, "Error saving response", Toast.LENGTH_SHORT).show();
            Log.e("SaveResponse", "Error saving response: " + e.getMessage());
        }
    }


    private void deletePendingResponse(String repUser) {
        File pendingFolder = new File(getFilesDir(), pendingRespondsFolderName);
        File responseFile = new File(pendingFolder, respUser + ".txt");
        Log.d("respUser", repUser);

        if (responseFile.exists()) {
            if (responseFile.delete()) {
                Log.i("DeleteResponse", "Pending response deleted successfully");
                for (int i = 0; i < llSavedTexts.getChildCount(); i++) {
                    View childView = llSavedTexts.getChildAt(i);
                    if (childView instanceof TextView) {
                        TextView textView = (TextView) childView;
                        String userText = textView.getText().toString();
                        if (userText.contains("User: " + repUser)) {
                            llSavedTexts.removeView(textView);
                            break;
                        }
                    }
                }
            } else {
                Log.e("DeleteResponse", "Error deleting pending response");
            }
        } else {
            Log.i("DeleteResponse", "Pending response file does not exist");
        }
    }



    private File getOrCreateFolder(String folderName) {
        File folder = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), folderName);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return folder;
    }


    private void loadSavedTexts() {
        File folder = new File(getFilesDir(), "PendingResponds");
        File[] files = folder.listFiles();

        if (files != null && files.length > 0) {
            for (File file : files) {
                String fileName = file.getName();
                String userName = fileName.substring(0, fileName.lastIndexOf('.'));
                String text = readTextFromFile(file);

                TextView textView = new TextView(this);
                textView.setText("User: " + userName + "\n" + "Message: " + text);
                llSavedTexts.addView(textView);
            }
        } else {
            TextView textView = new TextView(this);
            textView.setText("No saved texts found.");
            llSavedTexts.addView(textView);
        }
    }

    private String readTextFromFile(File file) {
        StringBuilder content = new StringBuilder();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content.toString().trim();
    }
}