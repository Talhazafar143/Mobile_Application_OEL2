package com.example.samdoel2;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ProfileActivity extends AppCompatActivity {

    private String userName;
    private String userEmail;
    private String userRole;
    private Button btnNotify;
    private Button btnReadSettledResponse;

    private String pendingRespondsFolderName = "PendingResponds";
    private String settledRespondsFolderName = "SettledResponds";
    private TextView resCont;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        resCont=findViewById(R.id.textView);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            Intent intent = getIntent();
            userName = intent.getStringExtra("name");
            userEmail = intent.getStringExtra("email");
            userRole = intent.getStringExtra("role");

            // Use the retrieved values as needed
            TextView nameTextView = findViewById(R.id.nameTextView);
            nameTextView.setText("Name: "+userName);

            TextView emailTextView = findViewById(R.id.emailTextView);
            emailTextView.setText("Email: "+userEmail);

            TextView roleTextView = findViewById(R.id.roleTextView);
            roleTextView.setText("Role: "+userRole);
        }

        Button btnLogout = findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, Login.class);
                startActivity(intent);
                finish();
            }
        });

        btnNotify = findViewById(R.id.btnNotify);
        btnReadSettledResponse = findViewById(R.id.btnReadSettledResponse);

        btnNotify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isUserNotified()) {
                    Toast.makeText(ProfileActivity.this, "You have already been notified.", Toast.LENGTH_SHORT).show();
                } else {
                    showNotifyDialog();
                }
            }
        });




        btnReadSettledResponse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (userRole.equals("Citizen")) {
                    readSettledResponse();
                }
            }
        });
    }


    private boolean isUserNotified() {
        String fileName = userEmail + ".txt";
        File pendingRespondsFolder = new File(getFilesDir(), pendingRespondsFolderName);
        String folderLocation = pendingRespondsFolder.getPath();
        System.out.println("Pending Responds Folder Location: " + folderLocation);
        if (pendingRespondsFolder.exists()) {
            File[] files = pendingRespondsFolder.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.getName().equals(fileName)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }
    private void showNotifyDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ProfileActivity.this);
        builder.setTitle("Emergency Notification");
        builder.setMessage("Enter your emergency message:");

        final EditText etEmergencyMessage = new EditText(ProfileActivity.this);
        builder.setView(etEmergencyMessage);

        builder.setPositiveButton("Notify", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String emergencyMessage = etEmergencyMessage.getText().toString().trim();
                if (!emergencyMessage.isEmpty()) {
                    notifyEmergencyResponders(emergencyMessage);
                }
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    private void notifyEmergencyResponders(String emergencyMessage) {
        String fileName = userEmail + ".txt";
        String content = emergencyMessage;

        saveNotification(pendingRespondsFolderName, fileName, content);

        Toast.makeText(ProfileActivity.this, "Notification sent to emergency responders", Toast.LENGTH_SHORT).show();
    }

    private void readSettledResponse() {
        File settledFolder = getOrCreateFolder(settledRespondsFolderName);

        String fileName = userEmail;
        Log.d("UserEmail",fileName);
        File settledFile = new File(settledFolder, fileName);

        if (settledFile.exists()) {
            String settledResponse = readNotification(settledFile);
            if (settledResponse.isEmpty()) {
                Toast.makeText(ProfileActivity.this, "Settled response not available", Toast.LENGTH_SHORT).show();
            } else {
                showSettledResponseDialog(settledResponse, settledFile);
            }
        } else {

            Toast.makeText(ProfileActivity.this, "Settled response not available", Toast.LENGTH_SHORT).show();
        }
    }

    private void showSettledResponseDialog(String response, final File settledFile) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getApplicationContext());
        builder.setTitle("Settled Response");
        builder.setMessage(response);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();

        // Log file path and content
        Log.d("File Path", settledFile.getAbsolutePath());
        Log.d("File Content", response);
        resCont.setText(response);

    }


    private String readNotification(File file) {
        StringBuilder sb = new StringBuilder();
        try {
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                sb.append(scanner.nextLine());
            }
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(ProfileActivity.this, "Error reading notification", Toast.LENGTH_SHORT).show();
        }
        return sb.toString();
    }


    private void saveNotification(String folderName, String fileName, String content) {
        File folder = getOrCreateFolder(folderName);

        File file = new File(folder, fileName);
        try {
            FileWriter writer = new FileWriter(file);
            writer.write(content);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(ProfileActivity.this, "Error saving notification", Toast.LENGTH_SHORT).show();
        }
    }



    private void deleteSettledResponse(File file) {
        if (file.delete()) {
            Toast.makeText(ProfileActivity.this, "Settled response deleted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(ProfileActivity.this, "Error deleting settled response", Toast.LENGTH_SHORT).show();
        }
    }

    private File getOrCreateFolder(String folderName) {
        File folder = new File(getFilesDir(), folderName);
        if (!folder.exists()) {
            if (folder.mkdirs()) {
                Log.d("ProfileActivity", "Folder created: " + folder.getAbsolutePath());
            } else {
                Log.e("ProfileActivity", "Failed to create folder: " + folder.getAbsolutePath());
            }
        }
        return folder;
    }

}
